﻿using ExplorerPCal.Utils;

namespace ExplorerPCal.Models
{
    public class Logs : AsyncObservableCollection<Log>
    {
    }
}