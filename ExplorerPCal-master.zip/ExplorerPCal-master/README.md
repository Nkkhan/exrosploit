﻿ExplorerPCal
=======
![ExplorerPCal](https://raw.githubusercontent.com/VahidN/ExplorerPCal/master/Bin/pcal01.png)


- In English:
   - [Replacing the default Windows calendar with .NET hooks](http://www.codeproject.com/Articles/690216/Replacing-the-default-Windows-calendar-with-NET-ho)
- In Persian:
   - [&#x202b;تغییر عملکرد و یا ردیابی توابع ویندوز با استفاده از Hookهای دات نتی](http://www.dotnettips.info/post/1519/%d8%aa%d8%ba%db%8c%db%8c%d8%b1-%d8%b9%d9%85%d9%84%da%a9%d8%b1%d8%af-%d9%88-%db%8c%d8%a7-%d8%b1%d8%af%db%8c%d8%a7%d8%a8%db%8c-%d8%aa%d9%88%d8%a7%d8%a8%d8%b9-%d9%88%db%8c%d9%86%d8%af%d9%88%d8%b2-%d8%a8%d8%a7-%d8%a7%d8%b3%d8%aa%d9%81%d8%a7%d8%af%d9%87-%d8%a7%d8%b2-hook%d9%87%d8%a7%db%8c-%d8%af%d8%a7%d8%aa-%d9%86%d8%aa%db%8c)
   - [بهبود شمسی ساز تاریخ اکسپلورر ویندوز جهت سازگاری با ویندوزهای سری 8](http://www.dotnettips.info/post/1734/%d8%a8%d9%87%d8%a8%d9%88%d8%af-%d8%b4%d9%85%d8%b3%db%8c-%d8%b3%d8%a7%d8%b2-%d8%aa%d8%a7%d8%b1%db%8c%d8%ae-%d8%a7%da%a9%d8%b3%d9%be%d9%84%d9%88%d8%b1%d8%b1-%d9%88%db%8c%d9%86%d8%af%d9%88%d8%b2-%d8%ac%d9%87%d8%aa-%d8%b3%d8%a7%d8%b2%da%af%d8%a7%d8%b1%db%8c-%d8%a8%d8%a7-%d9%88%db%8c%d9%86%d8%af%d9%88%d8%b2%d9%87%d8%a7%db%8c-%d8%b3%d8%b1%db%8c-8)
